package org.firstinspires.ftc.teamcode._AUTON;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode._CONFIG.Hware;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

/*
 * This is an example of a more complex path to really test the tuning.
 */
@Autonomous(group = "drive")
public class Auton extends LinearOpMode {

    Boolean RUNNOTON = true;
    Boolean RUNNOTONV = true;

    double SPEEDCONTROL = 1;
    double TURNCONTROL = 1;
    String vMSG = "PICK";
    String hMSG = "PICK";
    Hware robot;

    public void changeHorizontalPosition(int Position) {
        RUNNOTON = false;
        robot.horizontal1.setTargetPosition(Position);
        robot.horizontal2.setTargetPosition(Position);
        robot.horizontal1.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        robot.horizontal2.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    }

    public void changeVerticalPosition(int Position) {
        RUNNOTONV = false;
        robot.vertical1.setTargetPosition(Position);
        robot.vertical1.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    }

    // INTAKE PORTION
    public void rotateToDrop() {
        robot.pR.setPosition(0.1);
        robot.pL.setPosition(.9);
    }

    public void rotateToPick() {
        robot.pR.setPosition(1);
        robot.pL.setPosition(0);
    }

    public void openPickUpClaw() {
        robot.claw.setPosition(0);
    }

    public void closePickUpClaw() {
        robot.claw.setPosition(1);
    }

    // OUTAKE PORTION
    public void transferRotateToDrop() {
        robot.vRot1.setPosition(0);
        robot.vRot2.setPosition(1);
        robot.clawRot.setPosition(0);
    }

    public void transferRotateToPick() {
        robot.vRot1.setPosition(0.85);
        robot.vRot2.setPosition(0.25);
        robot.clawRot.setPosition(1);
    }

    public void transferOpenClaw() {
        robot.vClaw.setPosition(0);
    }

    public void transferCloseClaw() {
        robot.vClaw.setPosition(1);
    }

    @Override
    public void runOpMode() throws InterruptedException {
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        robot = new Hware();
        robot.initialize(hardwareMap);


        waitForStart();

        if (isStopRequested()) return;

        Trajectory preload = drive.trajectoryBuilder(new Pose2d())
                .addTemporalMarker(0, ()->{
                    transferCloseClaw();
                })
                .addTemporalMarker(0.2, ()->{
                    changeVerticalPosition(2000);
                    robot.vertical1.setPower(1);
                    transferRotateToDrop();
                })
                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(-25, -11), Math.toRadians(180))
                .addDisplacementMarker(()->{
                    changeVerticalPosition(450);
                    robot.vertical1.setPower(1);
                    transferRotateToDrop();
                })
                .build();

        Trajectory releaseClaw = drive.trajectoryBuilder(new Pose2d())
                .addTemporalMarker(0, ()->{
                    transferOpenClaw();
                })
                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .build();

        Trajectory vertSlideDown = drive.trajectoryBuilder(new Pose2d())
                .addTemporalMarker(0, ()->{
                    changeVerticalPosition(0);
                    robot.vertical1.setPower(1);
                    transferRotateToDrop();
                })
                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .build();

        Trajectory lineToPick1 = drive.trajectoryBuilder(new Pose2d())
                .addTemporalMarker(0, ()->{
                    transferRotateToPick();
                    changeHorizontalPosition(1670);
                    robot.horizontal1.setPower(0.3);
                    robot.horizontal2.setPower(0.3);
                    rotateToDrop();
                })
                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineTo(new Vector2d(19.8, 36), Math.toRadians(165))
                .build();
        Trajectory pickFromGround = drive.trajectoryBuilder(new Pose2d())

                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(-5, 20), Math.toRadians(0))
                .build();


        Trajectory pullBackHorSlides = drive.trajectoryBuilder(new Pose2d())
                .addTemporalMarker(0, ()->{
                    transferRotateToPick();
                    changeHorizontalPosition(3);
                    robot.horizontal1.setPower(1);
                    robot.horizontal2.setPower(1);
                    rotateToPick();
                })
                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(-40, 20), Math.toRadians(0))
                .build();

        Trajectory pushSecond = drive.trajectoryBuilder(new Pose2d())

                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(60, 30), Math.toRadians(0))
                .build();

        Trajectory thirdBackup = drive.trajectoryBuilder(new Pose2d())

                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(-60, 0), Math.toRadians(0))
                .build();

        Trajectory pushThird = drive.trajectoryBuilder(new Pose2d())

                //.splineToConstantHeading(new Vector2d(0.1, 0), Math.toRadians(180))
                .splineToConstantHeading(new Vector2d(60, 25.5), Math.toRadians(0))
                .build();

        drive.followTrajectory(preload);
        sleep(200);
        drive.followTrajectory(releaseClaw);
        sleep(500);
        drive.followTrajectory(vertSlideDown);
        sleep(20);
        drive.followTrajectory(lineToPick1);
        sleep(1000);
        closePickUpClaw();
        sleep(500);
        drive.followTrajectory(pickFromGround);
        sleep(500);
        openPickUpClaw();
        sleep(200);
        drive.followTrajectory(pullBackHorSlides);
        sleep(100);
        drive.followTrajectory(pushSecond);
        sleep(100);
        drive.followTrajectory(thirdBackup);
        sleep(100);
        drive.followTrajectory(pushThird);

    }
}
